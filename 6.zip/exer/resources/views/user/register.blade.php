@include('partials.loginheader')
<div class="wrapper fadeInDown">
  <div id="formContent">
    <!-- Tabs Titles -->

   

    <!-- Login Form -->
    <form action="/store" method="POST">

      @csrf 

      @error('email')
      <p>Invalid Account</p>
      @enderror
      
      <input type="text" id="login" class="fadeIn second" name="name" placeholder="Name">
      <input type="email" id="login" class="fadeIn second" name="email" placeholder="Email">
      <input type="password" id="password" class="fadeIn third" name="password" placeholder="Password">
      <input type="password" id="password" class="fadeIn third" name="password_confirmation" placeholder="Confrim Password">
      <input type="submit" class="fadeIn fourth" value="Log In">
    </form>

    <!-- Remind Passowrd -->
    <div id="formFooter">
      <a class="underlineHover" href="/login">Try to LogIn</a>
      
    </div>

  </div>
</div>