@include('partials.loginheader')
<div class="wrapper fadeInDown">
  <div id="formContent">
    <!-- Tabs Titles -->

   

    <!-- Login Form -->
    <form action="/login/process" method="POST">

      @csrf 

      @error('email')
      <p>Invalid Account</p>
      @enderror
      
      <input type="email" id="login" class="fadeIn second" name="email" placeholder="login">
      <input type="password" id="password" class="fadeIn third" name="password" placeholder="password">
      <input type="submit" class="fadeIn fourth" value="Log In">
    </form>

    <!-- Remind Passowrd -->
    <div id="formFooter">
      <a class="underlineHover" href="#">Forgot Password?</a>
      <br>
      <a class="underlineHover" href="/register">Create an account</a>
    </div>

  </div>
</div>
