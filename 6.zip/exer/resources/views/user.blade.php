Name: {{$name}}
<br>
Age: {{$age}}
<br>
Email: {{$email}}