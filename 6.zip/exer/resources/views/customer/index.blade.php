@include('partials.headertable')



<table class="table table-dark">
  <thead>
    <tr>
      <th scope="col">ID</th>
      <th scope="col">First Name</th>
      <th scope="col">Last Name</th>
      <th scope="col">Contact Number</th>
      <th scope="col">Address</th>
      <th scope="col">Email</th>
      <th ></th>
     
    </tr>
  </thead>
  <tbody>
  @foreach($customers as $customer)
    <tr>
      <th >{{$customer->id}}</th>
      <td>{{$customer->firstName}}</td>
      <td>{{$customer->lastName}}</td>
      <td>{{$customer->contactNumber}}</td>
      <td>{{$customer->address}}</td>
      <td>{{$customer->email}}</td>
      <td>
        <a href="delete/{{$customer->id}}">Delete</a>
        <a></a>
     
        <a href="edit/{{$customer->id}}">Edit</a>
      </td>
     
    </tr>

  </tbody>
  @endforeach
</table>

