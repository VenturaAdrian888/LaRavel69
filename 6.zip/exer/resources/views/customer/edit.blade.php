@include('partials.headertable')

<h1>Update Member</h1>
<form action="/edit" method="Post">
    @csrf
    <input type="text" name="id" value="{{$customer->id}}"> <br><br>
    <input type="text" name="firstName" value="{{$customer->firstName}}"> <br><br>
    <input type="text" name="lastName" value="{{$customer->lastName}}"> <br><br>
    <input type="text" name="contactNumber" value="{{$customer->contactNumber}}"> <br><br>
    <input type="text" name="address" value="{{$customer->address}}"> <br><br>
    <input type="text" name="email" value="{{$customer->email}}"> <br><br>
    <button type="submit">Update</button>


</form>