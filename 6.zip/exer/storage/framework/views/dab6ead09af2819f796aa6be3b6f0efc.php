<?php echo $__env->make('partials.headertable', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



<table class="table table-dark">
  <thead>
    <tr>
      <th scope="col">ID</th>
      <th scope="col">First Name</th>
      <th scope="col">Last Name</th>
      <th scope="col">Contact Number</th>
      <th scope="col">Address</th>
      <th scope="col">Email</th>
      <th ></th>
     
    </tr>
  </thead>
  <tbody>
  <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <th ><?php echo e($customer->id); ?></th>
      <td><?php echo e($customer->firstName); ?></td>
      <td><?php echo e($customer->lastName); ?></td>
      <td><?php echo e($customer->contactNumber); ?></td>
      <td><?php echo e($customer->address); ?></td>
      <td><?php echo e($customer->email); ?></td>
      <td>
        <a href="delete/<?php echo e($customer->id); ?>">Delete</a>
        <a></a>
     
        <a href="edit/<?php echo e($customer->id); ?>">Edit</a>
      </td>
     
    </tr>

  </tbody>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>

<?php /**PATH C:\exer\resources\views/customer/index.blade.php ENDPATH**/ ?>