<?php echo $__env->make('partials.headertable', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<h1>Update Member</h1>
<form action="/edit" method="Post">
    <?php echo csrf_field(); ?>
    <input type="text" name="id" value="<?php echo e($customer->id); ?>"> <br><br>
    <input type="text" name="firstName" value="<?php echo e($customer->firstName); ?>"> <br><br>
    <input type="text" name="lastName" value="<?php echo e($customer->lastName); ?>"> <br><br>
    <input type="text" name="contactNumber" value="<?php echo e($customer->contactNumber); ?>"> <br><br>
    <input type="text" name="address" value="<?php echo e($customer->address); ?>"> <br><br>
    <input type="text" name="email" value="<?php echo e($customer->email); ?>"> <br><br>
    <button type="submit">Update</button>


</form><?php /**PATH C:\exer\resources\views/customer/edit.blade.php ENDPATH**/ ?>