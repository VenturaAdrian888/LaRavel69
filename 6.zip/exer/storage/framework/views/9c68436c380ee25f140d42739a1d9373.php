<?php echo $__env->make('partials.loginheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="wrapper fadeInDown">
  <div id="formContent">
    <!-- Tabs Titles -->

   

    <!-- Login Form -->
    <form action="/store" method="POST">

      <?php echo csrf_field(); ?> 

      <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
      <p>Invalid Account</p>
      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      
      <input type="text" id="login" class="fadeIn second" name="name" placeholder="Name">
      <input type="email" id="login" class="fadeIn second" name="email" placeholder="Email">
      <input type="password" id="password" class="fadeIn third" name="password" placeholder="Password">
      <input type="password" id="password" class="fadeIn third" name="password_confirmation" placeholder="Confrim Password">
      <input type="submit" class="fadeIn fourth" value="Log In">
    </form>

    <!-- Remind Passowrd -->
    <div id="formFooter">
      <a class="underlineHover" href="/login">Try to LogIn</a>
      
    </div>

  </div>
</div><?php /**PATH C:\exer\resources\views/user/register.blade.php ENDPATH**/ ?>