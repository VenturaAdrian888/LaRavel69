Name: <?php echo e($name); ?>

<br>
Age: <?php echo e($age); ?>

<br>
Email: <?php echo e($email); ?><?php /**PATH C:\exer\resources\views/user.blade.php ENDPATH**/ ?>