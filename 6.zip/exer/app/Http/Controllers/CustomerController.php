<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Validation\Rule;
use App\Models\Customer;
use Illuminate\Support\Facades\DB;
class CustomerController extends Controller
{
    public function index(){
        $data = Customer::all();
        return view('customer.index',['customers'=>$data]);
    }
    public function delete($id)
    {
       $delete=DB::table("customers")
       ->where("id", "=",$id)
       ->delete();

       return redirect('/')->with("success", "Customer deleted na");
    } 
    public function showData($id)
    {
        $data = Customer::find($id);
        return view('customer.edit',['customer'=>$data]);
    }
    public function updateCustomer(Request $req){
        $req->validate([
            "firstName"=>['required','min:4'],
            "lastName"=>['required','min:4'],
            "contactNumber"=>['required', 'min:11'],
            "address"=>['required','min:4'],

            "email"=>['required', 'email', 
            Rule::unique('users',)]
        ]);
        $data= Customer::find($req->id);
        $data->id=$req->id;
        $data->firstName=$req->firstName;
        $data->lastName=$req->lastName;
        $data->contactNumber=$req->contactNumber;
        $data->address=$req->address;
        $data->email=$req->email;
        $data->save();
        return redirect("/")->with('success', 'Customer was been Edited!');
    }

}
